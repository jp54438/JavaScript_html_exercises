console.log('Hello World')
document.write('Hello World')